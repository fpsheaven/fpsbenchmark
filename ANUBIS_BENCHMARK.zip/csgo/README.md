# fpsbenchmark
Benchmark your CSGO frames via this tool. Massive thank you to MrMaxim https://www.youtube.com/@MrMaxim and samisalreadytaken https://github.com/samisalreadytaken/csgo-benchmark  for laying the foundation for me to create this tool.


Download the ZIP from github and paste the "csgo" folder inside your CSGO directory.

Mine for example is "C:\Program Files (x86)\Steam\steamapps\common\Counter-Strike Global Offensive" 

Then,open console and type "map de_ancient"

Lastly,type "exec benchmark" and then "benchmark". The test lasts approx 1min,so be patient.

